package com.example.wisata.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import com.example.wisata.R;
import com.example.wisata.api.Api;
import com.example.wisata.model.ModelKomunitas;
import org.json.JSONException;
import org.json.JSONObject;

public class DetailKomunitasActivity extends AppCompatActivity {

    Toolbar tbDetailKomunitas;
    TextView tvNamaKomunitas, tvDesc;
    String idKomunitas, NamaKomunitas,Desc;
    ModelKomunitas modelKomunitas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_komunitas);

        tbDetailKomunitas = findViewById(R.id.tbDetailKomunitas);
        tbDetailKomunitas.setTitle("Detail Komunitas");
        setSupportActionBar(tbDetailKomunitas);
        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        modelKomunitas = (ModelKomunitas) getIntent().getSerializableExtra("detailKomunitas");
        if (modelKomunitas != null) {
            idKomunitas = modelKomunitas.getIdKomunitas();
            NamaKomunitas = modelKomunitas.getTxtNamaKomunitas();

            //set Id
            tvNamaKomunitas = findViewById(R.id.tvNamaKomunitas);
            tvDesc = findViewById(R.id.tvDesc);
            getDetailKomunitas();
        }
    }

    private void getDetailKomunitas() {
        AndroidNetworking.get(Api.DetailKomunitas)
                .addPathParameter("id", idKomunitas)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {

                                //get String Api
                                NamaKomunitas = response.getString("nama");
                                Desc = response.getString("deskripsi");

                                //set Text
                                tvNamaKomunitas.setText(NamaKomunitas);
                                tvDesc.setText(Desc);

                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(DetailKomunitasActivity.this,
                                        "Gagal menampilkan data!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Toast.makeText(DetailKomunitasActivity.this,
                                "Tidak ada jaringan internet!", Toast.LENGTH_SHORT).show();
                    }
                });
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
