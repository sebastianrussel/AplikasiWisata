package com.example.wisata.model;

import java.io.Serializable;


public class ModelKomunitas implements Serializable {

    private String idKomunitas, txtNamaKomunitas, GambarKomunitas, KategoriKomunitas, DeskripsiKomunitas;

    public String getIdKomunitas() {
        return idKomunitas;
    }

    public void setIdKomunitas(String idKomunitas) {
        this.idKomunitas = idKomunitas;
    }

    public String getTxtNamaKomunitas() {
        return txtNamaKomunitas;
    }

    public void setTxtNamaKomunitas(String txtNamaKomunitas) {
        this.txtNamaKomunitas = txtNamaKomunitas;
    }

    public String getGambarKomunitas() {
        return GambarKomunitas;
    }

    public void setGambarKomunitas(String gambarKomunitas) {
        GambarKomunitas = gambarKomunitas;
    }

    public String getKategoriKomunitas() {
        return KategoriKomunitas;
    }

    public void setKategoriKomunitas(String kategoriKomunitas) { KategoriKomunitas = kategoriKomunitas; }

    public String getDeskripsiKomunitas() {
        return DeskripsiKomunitas;
    }

    public void setDeskripsiKomunitas(String deskripsiKomunitas) { DeskripsiKomunitas = deskripsiKomunitas; }
}
